module.exports = {
  "homeType": "home",
  "expiryDate": new Date()
}
